var searchData=
[
  ['velocitymeasurementperiod',['VelocityMeasurementPeriod',['../class_c_a_n_talon.html#ae922250d78ec5d14ed2a4e502fda7374',1,'CANTalon']]]
];
