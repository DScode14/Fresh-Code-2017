var struct___t_a_l_o_n___control__5___general__10ms__t =
[
    [ "CurrentConditionMode_2", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a35d7158087481818d3849c24d1e81966", null ],
    [ "DemandH", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a94be513a0580bf49830cbf6f4b221ea6", null ],
    [ "DemandL", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a52016e23160e40627f9a3fddb7b68a70", null ],
    [ "DemandM", "struct___t_a_l_o_n___control__5___general__10ms__t.html#aac6702f366ffca2cbc7b14fd2883cf65", null ],
    [ "FeedbackDeviceSelect", "struct___t_a_l_o_n___control__5___general__10ms__t.html#aeefe52273ac8b1034b113e0a0948e796", null ],
    [ "ModeSelect", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a4d72a5b46212eb852e8fa31ef1957d2c", null ],
    [ "OverrideBrakeType", "struct___t_a_l_o_n___control__5___general__10ms__t.html#ac238ec9e22351c56b2249b95e1afa933", null ],
    [ "OverrideLimitSwitchEn", "struct___t_a_l_o_n___control__5___general__10ms__t.html#ae7279f53a77077cea4b4e98de1913eb4", null ],
    [ "ProfileSlotSelect", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a0f4a441215c70d1b0096c30b652d830f", null ],
    [ "RampThrottle", "struct___t_a_l_o_n___control__5___general__10ms__t.html#ac36d818a39287c8736039501dd9d4f30", null ],
    [ "ReservedZero", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a8013c91abd91d55ebd8a647b14809600", null ],
    [ "RevFeedbackSensor", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a68a1002a4aee7b4470c8f340dd6a73f3", null ],
    [ "RevMotDuringCloseLoopEn", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a38190850eceb5b793062ed35f64a5163", null ],
    [ "ThrottleBump_h3", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a214a7c3d836148d671e59eb02fb6ac4c", null ],
    [ "ThrottleBump_l8", "struct___t_a_l_o_n___control__5___general__10ms__t.html#a62f562dd5d2ac748a1a8e6a5a3c46882", null ]
];