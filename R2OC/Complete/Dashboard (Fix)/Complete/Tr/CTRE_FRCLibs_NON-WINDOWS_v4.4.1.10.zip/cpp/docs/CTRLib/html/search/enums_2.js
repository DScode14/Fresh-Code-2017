var searchData=
[
  ['gadgeteerconnection',['GadgeteerConnection',['../class_i_gadgeteer_uart_client.html#abd0f71dae586de68087d3e31494dc3f9',1,'IGadgeteerUartClient']]],
  ['gadgeteerproxytype',['GadgeteerProxyType',['../class_i_gadgeteer_uart_client.html#a693c525b55747540c040ad7ff874a251',1,'IGadgeteerUartClient']]],
  ['gadgeteerstate',['GadgeteerState',['../class_i_gadgeteer_uart_client.html#adbbdf69e122e1f633d32851fec5983ea',1,'IGadgeteerUartClient']]]
];
