var struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status =
[
    [ "bitrate", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html#ae9b87814c7c58d5b3712c81f126f83d8", null ],
    [ "conn", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html#a97e072ac9d70197fe26309117b6d40d3", null ],
    [ "resetCount", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html#a2f795d350895079d89ba2a79dec0ec4d", null ],
    [ "type", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html#ad64399bc939ac507052132c27e84fb0d", null ]
];