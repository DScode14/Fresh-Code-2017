var struct___t_a_l_o_n___control__1___general__10ms__t =
[
    [ "DemandH", "struct___t_a_l_o_n___control__1___general__10ms__t.html#ac5d18accc8841694a43f3e5e9cc71c5a", null ],
    [ "DemandL", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a23690e013e6bc8295c144a86b21a9410", null ],
    [ "DemandM", "struct___t_a_l_o_n___control__1___general__10ms__t.html#ac6beb943a42df59bcfa35dc4c0c4c876", null ],
    [ "FeedbackDeviceSelect", "struct___t_a_l_o_n___control__1___general__10ms__t.html#aaa9b3e168755e96b506e06ef5eb4f35c", null ],
    [ "ModeSelect", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a62f6315c433b511b837faeeb55b05f0a", null ],
    [ "OverrideBrakeType", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a19fbff2056e090ba2bdb3c0a71058f23", null ],
    [ "OverrideLimitSwitchEn", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a5a08d6f04af3ec02e6883847bcb554ce", null ],
    [ "ProfileSlotSelect", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a91eae14972edd6f37d1d1207bc5cea26", null ],
    [ "RampThrottle", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a42f3717bbb7b623511b9275ba1a89af7", null ],
    [ "RevFeedbackSensor", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a1a51e83d04c6bbaf3d9ab19d6d8dace6", null ],
    [ "RevMotDuringCloseLoopEn", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a98647d4d622c6017ee058a4b02ba6140", null ],
    [ "TokenH", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a2c0aa0cfbe0078585074b2e8c2a436fd", null ],
    [ "TokenL", "struct___t_a_l_o_n___control__1___general__10ms__t.html#a25e7fc990edb941c7a912d991952e4c8", null ]
];