var struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t =
[
    [ "huffCode_expect_0", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a347e363a6cb9e0ad39ea3bdcce6118ed", null ],
    [ "Idx", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#af26ee638771a1e56ce3d81df48b6d1ec", null ],
    [ "NextPt_DurationMs", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#ae2a5b4adf01f94e6f6e0605324a1c76e", null ],
    [ "NextPt_IsLast", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a36f5cc239e2b7d3595356e14983c3178", null ],
    [ "NextPt_PositionH", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a35df235e70f92ab650590005ef49dd5f", null ],
    [ "NextPt_PositionL", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#ac9e7776954fe8b393d4f22978554051b", null ],
    [ "NextPt_PositionM", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#ac174cf95210f1549ebd28273a179cfde", null ],
    [ "NextPt_ProfileSlotSelect", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a90d942243a80c21ad5413646d3059d82", null ],
    [ "NextPt_VelocityH", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a2ef0191fe6bb0b6f08bf32c85ebea602", null ],
    [ "NextPt_VelocityL", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a88258d783300f427d0467765599f20c7", null ],
    [ "NextPt_VelOnly", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a4613f2007f405033047902e4c41e6dad", null ],
    [ "NextPt_ZeroPosition", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a1146a7ff3ead032c1c3add2e9378bd90", null ],
    [ "reserved0", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a89a2b0b048f8ea491f4f5b4e96071fa9", null ],
    [ "reserved1", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff0__t.html#a36f71e8943f7c2d92899a86775b90cb2", null ]
];