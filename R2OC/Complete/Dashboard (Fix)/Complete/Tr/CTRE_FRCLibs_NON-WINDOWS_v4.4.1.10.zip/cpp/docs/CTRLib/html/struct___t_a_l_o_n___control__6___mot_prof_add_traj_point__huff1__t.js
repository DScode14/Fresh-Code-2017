var struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t =
[
    [ "huffCode_expect_1", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a045e98d9662a8f92e146cdbcbdda6479", null ],
    [ "Idx", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a6f95fea193b61d4337521cdc871d2d40", null ],
    [ "NextPt_Count", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#afeab609c8748706fd0b7a5ae09e73042", null ],
    [ "NextPt_DeltaPositionH", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#ad41ba69ff2581bb2eb1e9d35cab25971", null ],
    [ "NextPt_DeltaPositionL", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#ac54d670d8a4e1421afd6cae7bbbafcda", null ],
    [ "NextPt_DurationMs", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#acd1c819923ea24e3775046b4849be578", null ],
    [ "NextPt_IsLast", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a12495e0087b787ff9f82f75fc2e7fa5e", null ],
    [ "NextPt_ProfileSlotSelect", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a4d46a169dce87d0f19a5a219ea38a762", null ],
    [ "NextPt_SameVelocityH", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a9fdcefc3da53467a854b96fcae0b902d", null ],
    [ "NextPt_SameVelocityL", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a9fa3fa186784addeaa11bc732a9bd562", null ],
    [ "NextPt_VelOnly", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a92ebf6670dbf82dbe0eee2c9d4b78b99", null ],
    [ "NextPt_ZeroPosition", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#acf495fb4051c46ac58979d07aa097273", null ],
    [ "reserved0", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#ad55ef706ce737a0ed24437bec5ab94a3", null ],
    [ "reserved1", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__huff1__t.html#a40af54fdda763568a7f738f4612a0288", null ]
];