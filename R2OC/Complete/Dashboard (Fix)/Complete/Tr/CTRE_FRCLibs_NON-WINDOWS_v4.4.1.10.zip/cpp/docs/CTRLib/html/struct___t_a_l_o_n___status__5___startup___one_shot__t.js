var struct___t_a_l_o_n___status__5___startup___one_shot__t =
[
    [ "FirmVersH", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#aeccf4e0ed145cb1a66a3492b7736ce88", null ],
    [ "FirmVersL", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#a91caeef3bf9f02230b0bfce34acaa4dd", null ],
    [ "ResetCountH", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#aa2852f49cea45a82c524306c5e39c79f", null ],
    [ "ResetCountL", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#aedbf6ad0a83f78a5c063506513867885", null ],
    [ "ResetFlagsH", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#a7b0de09e2b27dad18d09b20f8affb4f2", null ],
    [ "ResetFlagsL", "struct___t_a_l_o_n___status__5___startup___one_shot__t.html#adee07f32dd5a01c0c1b5ada7c07c4b7e", null ]
];