var struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t =
[
    [ "huffCode", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a2cfc3a48230d640c121aa76c443e68e0", null ],
    [ "Idx", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#aac9b504910ea1066ab9cf07c32276470", null ],
    [ "NextPt_IsLast", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a48d1a46bc9c97c40f0604e39bf591cc8", null ],
    [ "NextPt_ProfileSlotSelect", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a1bac6323b2e02795abd39722a5c3a9b0", null ],
    [ "NextPt_VelOnly", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a0e7a389bceaea723afe4e701e319e423", null ],
    [ "NextPt_ZeroPosition", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#ad05eb4498805b0e0ef6ca4bdc65759d4", null ],
    [ "reserved0", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a6dcf978babcc990a7d19a0ac057c7637", null ],
    [ "reserved1", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#ab3079a42dbdd72dc5d2e9b830f4bac66", null ],
    [ "restOfFrame0", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a48a661ab989b0d20b2057c25a83c53e6", null ],
    [ "restOfFrame1", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#ab22f4de6cd6e5d72081d80b4da5d53e1", null ],
    [ "restOfFrame2", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a2b66b6d406d7a777eadca99561575b49", null ],
    [ "restOfFrame3", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a3e2ce62d3193a658ef9f74627457931d", null ],
    [ "restOfFrame4", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a173f6dcd1864e355c1140663fe552e17", null ],
    [ "restOfFrame5", "struct___t_a_l_o_n___control__6___mot_prof_add_traj_point__t.html#a9ede70b6d1a81c56925fb09e3e14d0a4", null ]
];