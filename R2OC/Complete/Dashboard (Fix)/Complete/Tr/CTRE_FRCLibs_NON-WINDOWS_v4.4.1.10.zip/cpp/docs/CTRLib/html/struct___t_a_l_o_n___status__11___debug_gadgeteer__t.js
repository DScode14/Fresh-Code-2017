var struct___t_a_l_o_n___status__11___debug_gadgeteer__t =
[
    [ "GadgeteerUart_BitrateH", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a1d95ce7da906e51e96fd3104d56fe310", null ],
    [ "GadgeteerUart_BitrateL", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a5ae3ff3504ccfbceca8ca34188d55602", null ],
    [ "GadgeteerUart_ChirpRxCnt", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a174a402e3774869313cb6ba240cf7286", null ],
    [ "GadgeteerUart_DiagStatus", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a0346d820310aaf8c1cd9f3eaace3d377", null ],
    [ "GadgeteerUart_ResetCnt", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a411c932ae1eb8a58983a6f7729de8786", null ],
    [ "GadgeteerUart_RetryTotalCnt", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a671eda2b6453c51d32f224d9e168744c", null ],
    [ "GadgeteerUart_State", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a26141bb47942bd370153eb20cc96b3c2", null ],
    [ "GadgeteerUart_TxCnt", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#ae8f12115d30bd65aaa6b85148e0be8df", null ],
    [ "GadgeteerUart_Type", "struct___t_a_l_o_n___status__11___debug_gadgeteer__t.html#a3a326b043a823ec007e2a7b7ff99728d", null ]
];