var struct_pigeon_imu_1_1_fusion_status =
[
    [ "bIsFusing", "struct_pigeon_imu_1_1_fusion_status.html#a26dd4c21e27118aa1eb9efffe4059f48", null ],
    [ "bIsValid", "struct_pigeon_imu_1_1_fusion_status.html#a09db898f92aece7aa8e26d9e181cbafd", null ],
    [ "description", "struct_pigeon_imu_1_1_fusion_status.html#a3aec3a1a6919d3e47dcc48e2f1032317", null ],
    [ "heading", "struct_pigeon_imu_1_1_fusion_status.html#aa0b4d08f79b917d476477a635e67e99b", null ],
    [ "lastError", "struct_pigeon_imu_1_1_fusion_status.html#a441ba9a153a21bef98f8eeeba7c33d90", null ]
];