var struct___t_a_l_o_n___status__1___general__10ms__t =
[
    [ "AppliedThrottle_h3", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a84d66991126e83dced3a34d81debd65c", null ],
    [ "AppliedThrottle_l8", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a74ff7318e289b81fc5181763bad5d223", null ],
    [ "CloseLoopErrH", "struct___t_a_l_o_n___status__1___general__10ms__t.html#aca318f542433a15aad01ec0cb8ea79b0", null ],
    [ "CloseLoopErrL", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a56d4beb0bf17ac52d22bab1e57121ac8", null ],
    [ "CloseLoopErrM", "struct___t_a_l_o_n___status__1___general__10ms__t.html#add38dc97e89a77036a712ff4840bdf75", null ],
    [ "Fault_ForLim", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a45fca72e7076cfa79ca478dd5a0c3680", null ],
    [ "Fault_ForSoftLim", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a657231840e14cd37530bb108798d1ec1", null ],
    [ "Fault_HardwareFailure", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a79589b4c547635887d254ce039d6b132", null ],
    [ "Fault_OverTemp", "struct___t_a_l_o_n___status__1___general__10ms__t.html#af4c4d31533e7621c5a4b54ab9638b534", null ],
    [ "Fault_RevLim", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a309cbe0b8156325d5a052624a70d6884", null ],
    [ "Fault_RevSoftLim", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a0d28b183f01bdccf4350e1fb5c29415b", null ],
    [ "Fault_UnderVoltage", "struct___t_a_l_o_n___status__1___general__10ms__t.html#aa58fe70f715c08419f5fe180b88454c4", null ],
    [ "FeedbackDeviceSelect", "struct___t_a_l_o_n___status__1___general__10ms__t.html#acddcad8cc0fdd8bb4f97d70239b2d021", null ],
    [ "LimitSwitchClosedFor", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a57110c7a2e2ec2cd5cd8e18c8fac86ed", null ],
    [ "LimitSwitchClosedRev", "struct___t_a_l_o_n___status__1___general__10ms__t.html#abcef5bea95781275e81433ff03e0c189", null ],
    [ "LimitSwitchEn", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a6090fb491206496f9fbda5ffa09ed871", null ],
    [ "ModeSelect_b3", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a1df0851e0cf2ca863cc3da2e64bf3d57", null ],
    [ "ModeSelect_h1", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a1b41d4fb5c92039462f656e886985ce1", null ],
    [ "TokenSeed", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a037f28017dc795cd4fd28f3683f09a01", null ],
    [ "TokLocked", "struct___t_a_l_o_n___status__1___general__10ms__t.html#a6223ced1c5465dc47417b83fcf9c8084", null ]
];