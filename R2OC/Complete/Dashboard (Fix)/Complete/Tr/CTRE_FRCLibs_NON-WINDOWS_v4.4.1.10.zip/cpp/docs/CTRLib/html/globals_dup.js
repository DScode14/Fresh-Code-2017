var globals_dup =
[
    [ "b", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "e", "globals_e.html", null ],
    [ "i", "globals_i.html", null ],
    [ "j", "globals_j.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ],
    [ "w", "globals_w.html", null ]
];