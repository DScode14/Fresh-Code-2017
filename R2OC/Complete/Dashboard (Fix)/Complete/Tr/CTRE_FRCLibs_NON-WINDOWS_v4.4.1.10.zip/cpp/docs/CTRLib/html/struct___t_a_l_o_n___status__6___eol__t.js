var struct___t_a_l_o_n___status__6___eol__t =
[
    [ "analogAdcUncal_h2", "struct___t_a_l_o_n___status__6___eol__t.html#a06a523f4f6b3820db84da8fc7c4bf931", null ],
    [ "analogAdcUncal_l8", "struct___t_a_l_o_n___status__6___eol__t.html#a120025e45e457089d4f0cb9ca632b0c0", null ],
    [ "currentAdcUncal_h2", "struct___t_a_l_o_n___status__6___eol__t.html#ae126fa8291211af09d578eeffe1c8136", null ],
    [ "currentAdcUncal_l8", "struct___t_a_l_o_n___status__6___eol__t.html#a38a3e6a982d2b3f84db613007158989b", null ],
    [ "reserved1", "struct___t_a_l_o_n___status__6___eol__t.html#a37cc1a45165c817c3475d4fcf83c72f4", null ],
    [ "reserved2", "struct___t_a_l_o_n___status__6___eol__t.html#a6e074e11c5ff139bc51867cbc2657bad", null ],
    [ "reserved3", "struct___t_a_l_o_n___status__6___eol__t.html#a781db78ee9eb8706aeb8d28c6a6b3adc", null ],
    [ "reserved4", "struct___t_a_l_o_n___status__6___eol__t.html#ab50b5bd17f6e4d0fc90f85a87463fab1", null ],
    [ "SpiCsPin_GadgeteerPin6", "struct___t_a_l_o_n___status__6___eol__t.html#ab51a74666ef3d75e97b6e4b083bbd12f", null ],
    [ "tempAdcUncal_h2", "struct___t_a_l_o_n___status__6___eol__t.html#a3d334357550aa76f4a0d05d31b00f912", null ],
    [ "tempAdcUncal_l8", "struct___t_a_l_o_n___status__6___eol__t.html#ace79ef66f3f3a8903ec50574b8763408", null ],
    [ "vbatAdcUncal_h2", "struct___t_a_l_o_n___status__6___eol__t.html#ab76be430b649881d5481450efafb6ce3", null ],
    [ "vbatAdcUncal_l8", "struct___t_a_l_o_n___status__6___eol__t.html#a6adaf6710d97371d3a953caea0f70c29", null ]
];