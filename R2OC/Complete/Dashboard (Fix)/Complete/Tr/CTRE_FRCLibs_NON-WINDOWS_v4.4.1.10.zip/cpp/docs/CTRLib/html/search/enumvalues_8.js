var searchData=
[
  ['magnetometer12pt',['Magnetometer12Pt',['../class_pigeon_imu.html#a1d73ea84ad5c812e809698fab0b9b490a932992752b63b5ecdb211a8c3fc7a192',1,'PigeonImu']]],
  ['magnetometer360',['Magnetometer360',['../class_pigeon_imu.html#a1d73ea84ad5c812e809698fab0b9b490a5aa27d4ad1f20b83bbb4cac41a6ff0e8',1,'PigeonImu']]]
];
