var struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t =
[
    [ "ActTraj_IsLast", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a9df2d27c4784f37a2ca8d7dc8838f4a7", null ],
    [ "ActTraj_IsValid", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#aa27724b931bc0f8bd1f5b869c81141f2", null ],
    [ "ActTraj_PositionH", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#adda42310c66ff7056ffcb609ce36e728", null ],
    [ "ActTraj_PositionL", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#af549e4a9877f56d1ee817c5e3cb9fcda", null ],
    [ "ActTraj_PositionM", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a093818aefff4dff5be0cf10617f73aaa", null ],
    [ "ActTraj_ProfileSlotSelect", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#aef76f12f62cd4b19349dc03d21643f86", null ],
    [ "ActTraj_VelocityH", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a416251c78b1f62bb9b24e1f94b0d0211", null ],
    [ "ActTraj_VelocityL", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a7d99530c126bc3b069e01cd64ad4b774", null ],
    [ "ActTraj_VelOnly", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#aa7fa227a9a1047d67b651c122aa94aac", null ],
    [ "BufferIsFull", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a3190471d85367fac4b87ebbb2b7a4d80", null ],
    [ "Count", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a8bb46a11bc2e8f269899fd57d122f836", null ],
    [ "HasUnderrun", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a4ec9672b30280280b5cf33c043eaae9a", null ],
    [ "IsUnderrun", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a09ea2cc74d65ae3799ed8d3f8dc9168a", null ],
    [ "NextID", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a011e6d9248cbf42b162849d34a571ac8", null ],
    [ "OutputType", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#a522f46a072b37902d470ddbd7d1ee825", null ],
    [ "reserved1", "struct___t_a_l_o_n___status__9___mot_prof_buffer__100ms__t.html#ad5f0560fc7667fb5c2cde44482f1904a", null ]
];